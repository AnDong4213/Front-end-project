import 'babel-polyfill'
import '../css/index.css'
import Lottery from './lottery'

const syy = new Lottery()

console.log(syy)
