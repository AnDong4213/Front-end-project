module.exports = {
    "extends": "standard",
    "rules": {
      camelcase: 0
    }
};
